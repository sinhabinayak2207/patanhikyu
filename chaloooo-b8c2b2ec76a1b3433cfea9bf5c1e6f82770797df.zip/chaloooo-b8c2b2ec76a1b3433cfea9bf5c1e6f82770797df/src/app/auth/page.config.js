// This file tells Next.js not to statically generate this page
// It will be rendered only on the client side
export const dynamic = "force-dynamic";
export const runtime = "edge";

// Tawk.to Configuration
export const TAWK_SITE_ID = '687e53247697a01914a21d66';
export const TAWK_WIDGET_ID = '1j0mn9icl';

// Contact Information
export const WHATSAPP_NUMBER = '+91-9876543210'; // Update with your actual WhatsApp number
export const EMAIL_ADDRESS = 'contact@occworldtrade.com'; // Update with your actual email

// Bot Configuration
export const BOT_NAME = 'OCC Assistant';
export const WELCOME_MESSAGE = 'Welcome to OCC World Trade! How can we help you today?';

export const siteConfig = {
  name: "OCC World Trade",
  description: "A modern B2B showcase application",
  url: "https://octopus-sh.netlify.app",
  links: {
    github: "https://github.com/sinhabinayak2207/octopus",
  },
};
